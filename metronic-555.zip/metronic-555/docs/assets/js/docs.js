$(document).ready(function () {
	hljs.initHighlightingOnLoad();
});